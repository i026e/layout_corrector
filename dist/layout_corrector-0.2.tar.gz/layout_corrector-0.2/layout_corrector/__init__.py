#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 11 16:37:07 2017

@author: pavel
"""

from layout_corrector.layout_corrector import Switcher

class Helper(object): pass
